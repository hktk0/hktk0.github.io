[![逼死前端狗](https://user-images.githubusercontent.com/1933673/187622714-694047e9-0388-483f-872b-65fb853fd4fa.jpg)](https://sojo.im)
# 💊「逼死前端狗」听说你是前端工程师？

这是一个逼死前端狗的前端页面，使用了大量优秀前端技术实现了前卫的界面设计。

## 地址 https://sojo.im

其实这是 二零一五年五月 整的一个活儿，起了个型就放着没管了。结果域名续到现在感觉好浪费 `(･ェ･。)`

想再征集些点子看看能不能“完善”下这个离谱项目😰

有什么关于逼死前端狗的点子欢迎来聊一聊，争取做成一个让前端工程师看到就高血压的项目 `ψ(｀∇´)ψ`

## 我有点子
[来聊一聊](https://github.com/itorr/sojo/issues/4) 

## GitHub
https://github.com/itorr/sojo

## V2EX
https://www.v2ex.com/t/876750

## 协议
MIT ©itorr
